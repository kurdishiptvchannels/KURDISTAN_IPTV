
KURDISTAN IPTV - Android Studio Project
=======================================

1) Open this folder in Android Studio.
2) Let Gradle sync.
3) Use JDK 17.
4) Build > Build APK(s).
5) The debug APK will be under:
   app/build/outputs/apk/debug/app-debug.apk

App:
- Name: KURDISTAN IPTV
- Package: com.kurdistan.iptv
- Minimum Android: 7.0 (API 24)
- Activation code: 1015 (not shown in the app UI)
- Native Android player: Media3 ExoPlayer, supports HLS and common TS streams.
- Web fallback: the included WebView page.
- RTL UI and Kurdish/English/Arabic language selector.
- Categories separate Kurdish, Movies/Drama, Sports, Kids, Quran, Arabic, Education, Music and Documentary.

IMPORTANT:
The stream URLs supplied by the requester are included as provided for the prototype. Stream availability, CORS, authentication, geo restrictions, and copyright/licensing are not verified. Only use streams you are authorized to distribute.
